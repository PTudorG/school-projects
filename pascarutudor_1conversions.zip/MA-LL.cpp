#include<fstream>
#include<iostream>
using namespace std;

int main()
{ int n,a[100][100];
int x=0;

    fstream f;
    f.open("input_f.dat",ios::in);

    f>>n;
    for(int i=0;i<n;i++)
    for(int j=0;j<n;j++)
        f>>a[i][j];

    fstream g;
    g.open("output_f.dat",ios::out);

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(a[i][j]==1) x++;
        }
        g<<x<<" ";
         for(int j=0;j<n;j++)
        {
            if(a[i][j]==1) g<<j+1<<" ";
        }
        for(int j=0;j<n-x-1;j++) g<<0<<" ";
         g<<endl;
         x=0;


    }


    f.close();
    g.close();
}
