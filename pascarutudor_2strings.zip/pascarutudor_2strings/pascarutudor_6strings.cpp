#include<iostream>
#include<stdio.h>
#include<string.h>
#include<string>
using namespace std;

int main()
{
    char a[50],b[50],c;
    cout<<"a=";
    gets(a); int i,j,x=0;
    for(i=0;i<strlen(a);i++)
    {
        if(a[i]=='.') {j=i; break;}
    }
    strncpy(b,a,j+1);
    b[j+1]=0;
    cout<<a<<endl<<b;
    i=0;
    while(b[i])
    {c=b[i];
    if(isspace(c)) x++;
    i++;}
    if(isspace(b[0]))
    cout<<endl<<x;
    else cout<<endl<<x+1;

}
