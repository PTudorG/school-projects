#include<iostream>
#include<stdio.h>
#include<string.h>
#include<string>
using namespace std;

char a[50]; int i;
void gotonextword()
{
    while(isspace(a[i])==0 && ispunct(a[i])==0 && a[i]!=0)
        i++;
}
int main()
{
    char b[50];
    cout<<"a=";
    gets(a);
    cout<<"b=";
    gets(b);
    int j=0,w=0;
    i=0;
    while(i<strlen(a))
    {
        if(a[i]==b[0]){
            for(j=0;j<strlen(b);j++)
        {
            if(a[i+j]!=b[j])
                {gotonextword();
                break;}
        }
        if(j==strlen(b)){
            if(isspace(a[i+j]) || ispunct(a[i+j]) || a[i+j]==0  )
            {
                w++;
                i=i+j;

            }
        }
    }
    else gotonextword();

        i++;
    }
    cout<<w;



}
